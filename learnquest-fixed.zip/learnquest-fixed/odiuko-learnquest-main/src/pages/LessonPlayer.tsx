import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { ArrowLeft, CheckCircle, BookOpen } from "lucide-react";
import Layout from "@/components/Layout";
import logo from "@/assets/odiuko-shield-transparent.png";

export default function LessonPlayer() {
  const { lessonId } = useParams<{ lessonId: string }>();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [lesson, setLesson] = useState<any>(null);
  const [completed, setCompleted] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!lessonId) return;
    const fetch = async () => {
      const { data } = await supabase.from("lessons").select("*").eq("id", lessonId).single();
      setLesson(data);
      if (user) {
        const { data: prog } = await supabase
          .from("student_progress")
          .select("completed")
          .eq("student_id", user.id)
          .eq("lesson_id", lessonId)
          .maybeSingle();
        setCompleted(prog?.completed ?? false);
      }
    };
    fetch();
  }, [lessonId, user]);

  const markComplete = async () => {
    if (!user || !lessonId) return;
    setLoading(true);
    const { error } = await supabase.from("student_progress").upsert(
      { student_id: user.id, lesson_id: lessonId, completed: true, completed_at: new Date().toISOString() },
      { onConflict: "student_id,lesson_id" }
    );
    if (error) {
      toast.error("Failed to save progress");
    } else {
      setCompleted(true);
      toast.success("Lesson completed! 🎉");
      await checkBadges();
    }
    setLoading(false);
  };

  const checkBadges = async () => {
    if (!user) return;
    const { data: progressData } = await supabase
      .from("student_progress")
      .select("lesson_id, lessons(subject)")
      .eq("student_id", user.id)
      .eq("completed", true);

    const totalCompleted = progressData?.length ?? 0;
    const bySubject: Record<string, number> = {};
    progressData?.forEach((p: any) => {
      const s = p.lessons?.subject;
      if (s) bySubject[s] = (bySubject[s] ?? 0) + 1;
    });

    const { data: allBadges } = await supabase.from("badges").select("*");
    const { data: earned } = await supabase.from("student_badges").select("badge_id").eq("student_id", user.id);
    const earnedIds = new Set((earned ?? []).map((e: any) => e.badge_id));

    for (const badge of allBadges ?? []) {
      if (earnedIds.has(badge.id)) continue;
      const count = badge.subject ? (bySubject[badge.subject] ?? 0) : totalCompleted;
      if (count >= badge.requirement_count) {
        await supabase.from("student_badges").insert({ student_id: user.id, badge_id: badge.id });
        toast.success(`🏆 Badge earned: ${badge.name}!`);
      }
    }
  };

  if (!lesson) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-pulse font-heading text-xl">Loading lesson...</div>
      </div>
    );
  }

  const headerContent = (
    <header className="bg-primary text-primary-foreground shadow-lg">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => navigate(-1)} className="text-primary-foreground hover:text-accent">
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <img src={logo} alt="LearnQuest" className="h-8 w-auto" />
          <h1 className="text-lg font-heading font-bold truncate">{lesson.title}</h1>
        </div>
        {completed && <Badge className="bg-accent text-accent-foreground">✓ Completed</Badge>}
      </div>
    </header>
  );

  return (
    <Layout header={headerContent}>
      {/* Content */}
      <div className="flex-1 flex flex-col lg:flex-row">
        {/* Iframe */}
        <div className="flex-1 bg-muted">
          <iframe
            src={lesson.embed_url}
            className="w-full h-[60vh] lg:h-full border-0"
            allow="fullscreen; autoplay"
            title={lesson.title}
          />
        </div>

        {/* Sidebar */}
        <aside className="w-full lg:w-80 border-t lg:border-t-0 lg:border-l bg-card">
          <div className="p-6 space-y-6">
            <Card className="border-0 shadow-none">
              <CardHeader className="px-0 pt-0">
                <CardTitle className="text-lg font-heading flex items-center gap-2">
                  <BookOpen className="w-5 h-5 text-accent" /> Lesson Notes
                </CardTitle>
              </CardHeader>
              <CardContent className="px-0">
                <p className="text-sm text-muted-foreground whitespace-pre-wrap">
                  {lesson.notes || "No notes for this lesson."}
                </p>
              </CardContent>
            </Card>

            {!completed ? (
              <Button
                onClick={markComplete}
                disabled={loading}
                className="w-full bg-accent text-accent-foreground hover:bg-accent/90 font-semibold text-base py-6"
              >
                <CheckCircle className="w-5 h-5 mr-2" />
                {loading ? "Saving..." : "Mark as Complete"}
              </Button>
            ) : (
              <div className="text-center p-4 rounded-lg bg-accent/10 border border-accent/30">
                <CheckCircle className="w-8 h-8 text-accent mx-auto mb-2" />
                <p className="font-heading font-semibold">Great job! 🎉</p>
                <p className="text-sm text-muted-foreground">You've completed this lesson.</p>
              </div>
            )}
          </div>
        </aside>
      </div>
    </Layout>
  );
}
