import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { toast } from "sonner";
import { ArrowLeft, Plus, Trash2, Shield, UserCheck, UserX, KeyRound, Copy, RefreshCw, Users, BookOpen, Activity } from "lucide-react";
import Layout from "@/components/Layout";

const classLevels = [
  { value: "basic_1", label: "Basic 1" }, { value: "basic_2", label: "Basic 2" },
  { value: "basic_3", label: "Basic 3" }, { value: "basic_4", label: "Basic 4" },
  { value: "basic_5", label: "Basic 5" }, { value: "basic_6", label: "Basic 6" },
];

const classLabels: Record<string, string> = {
  basic_1: "Basic 1", basic_2: "Basic 2", basic_3: "Basic 3",
  basic_4: "Basic 4", basic_5: "Basic 5", basic_6: "Basic 6",
};

function generateCode() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  for (let i = 0; i < 8; i++) code += chars[Math.floor(Math.random() * chars.length)];
  return code;
}

export default function Admin() {
  const { isAdmin, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [lessons, setLessons] = useState<any[]>([]);
  const [students, setStudents] = useState<any[]>([]);
  const [admins, setAdmins] = useState<any[]>([]);
  const [enrollmentCodes, setEnrollmentCodes] = useState<any[]>([]);
  const [loginActivity, setLoginActivity] = useState<any[]>([]);
  const [title, setTitle] = useState("");
  const [subject, setSubject] = useState<string>("science");
  const [classLevel, setClassLevel] = useState("basic_1");
  const [embedUrl, setEmbedUrl] = useState("");
  const [notes, setNotes] = useState("");
  const [adding, setAdding] = useState(false);
  const [adminEmail, setAdminEmail] = useState("");
  const [studentFilter, setStudentFilter] = useState("all");
  const [resetPasswordUserId, setResetPasswordUserId] = useState<string | null>(null);
  const [newPassword, setNewPassword] = useState("");
  const [codeClassLevel, setCodeClassLevel] = useState("basic_1");
  const [codeMaxUses, setCodeMaxUses] = useState("");

  useEffect(() => {
    if (!authLoading && !isAdmin) {
      navigate("/dashboard");
      return;
    }
    if (isAdmin) fetchData();
  }, [isAdmin, authLoading]);

  const fetchData = async () => {
    const [lessonsRes, studentsRes, adminsRes, codesRes, activityRes] = await Promise.all([
      supabase.from("lessons").select("*").order("created_at", { ascending: false }),
      supabase.from("profiles").select("*").order("created_at", { ascending: false }),
      supabase.from("user_roles").select("*").eq("role", "admin" as any),
      supabase.from("enrollment_codes").select("*").order("created_at", { ascending: false }),
      supabase.from("login_activity").select("*").order("logged_in_at", { ascending: false }).limit(100),
    ]);
    setLessons(lessonsRes.data ?? []);
    setStudents(studentsRes.data ?? []);
    setAdmins(adminsRes.data ?? []);
    setEnrollmentCodes(codesRes.data ?? []);
    setLoginActivity(activityRes.data ?? []);
  };

  const callAdminAction = async (action: string, params: any) => {
    const { data, error } = await supabase.functions.invoke("admin-actions", {
      body: { action, ...params },
    });
    if (error) {
      toast.error(error.message);
      return false;
    }
    if (data?.error) {
      toast.error(data.error);
      return false;
    }
    return true;
  };

  const addLesson = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !embedUrl.trim()) {
      toast.error("Title and URL are required");
      return;
    }
    setAdding(true);
    const { error } = await supabase.from("lessons").insert({
      title: title.trim(),
      subject: subject as any,
      class_level: classLevel as any,
      embed_url: embedUrl.trim(),
      notes: notes.trim(),
    });
    if (error) toast.error(error.message);
    else {
      toast.success("Lesson added!");
      setTitle(""); setEmbedUrl(""); setNotes("");
      fetchData();
    }
    setAdding(false);
  };

  const deleteLesson = async (id: string) => {
    const { error } = await supabase.from("lessons").delete().eq("id", id);
    if (error) toast.error(error.message);
    else { toast.success("Lesson deleted"); fetchData(); }
  };

  const enrollStudent = async (userId: string, newClass: string) => {
    const ok = await callAdminAction("update_class", {
      user_id: userId,
      class_level: newClass,
      enrollment_status: "enrolled",
    });
    if (ok) { toast.success("Student enrolled!"); fetchData(); }
  };

  const moveStudent = async (userId: string, newClass: string) => {
    const ok = await callAdminAction("update_class", {
      user_id: userId,
      class_level: newClass,
    });
    if (ok) { toast.success("Student moved!"); fetchData(); }
  };

  const removeFromClass = async (userId: string) => {
    const ok = await callAdminAction("remove_from_class", { user_id: userId });
    if (ok) { toast.success("Student removed from class"); fetchData(); }
  };

  const toggleDeactivate = async (userId: string, currentlyActive: boolean) => {
    const ok = await callAdminAction("deactivate_student", {
      user_id: userId,
      deactivate: currentlyActive,
    });
    if (ok) {
      toast.success(currentlyActive ? "Student deactivated" : "Student reactivated");
      fetchData();
    }
  };

  const resetPassword = async () => {
    if (!resetPasswordUserId || !newPassword || newPassword.length < 6) {
      toast.error("Password must be at least 6 characters");
      return;
    }
    const ok = await callAdminAction("reset_password", {
      user_id: resetPasswordUserId,
      new_password: newPassword,
    });
    if (ok) {
      toast.success("Password reset successfully");
      setResetPasswordUserId(null);
      setNewPassword("");
    }
  };

  const createEnrollmentCode = async () => {
    const code = generateCode();
    const { error } = await supabase.from("enrollment_codes").insert({
      code,
      class_level: codeClassLevel as any,
      created_by: (await supabase.auth.getUser()).data.user!.id,
      max_uses: codeMaxUses ? parseInt(codeMaxUses) : null,
    });
    if (error) toast.error(error.message);
    else {
      toast.success(`Code created: ${code}`);
      setCodeMaxUses("");
      fetchData();
    }
  };

  const deleteCode = async (id: string) => {
    const { error } = await supabase.from("enrollment_codes").delete().eq("id", id);
    if (error) toast.error(error.message);
    else { toast.success("Code deleted"); fetchData(); }
  };

  if (authLoading) return <div className="min-h-screen flex items-center justify-center">Loading...</div>;

  const filteredStudents = students.filter((s) => {
    const isStudentAdmin = admins.some((a) => a.user_id === s.user_id);
    if (isStudentAdmin) return false; // Don't show admins in student list
    if (studentFilter === "all") return true;
    if (studentFilter === "pending") return s.enrollment_status === "pending";
    if (studentFilter === "enrolled") return s.enrollment_status === "enrolled";
    if (studentFilter === "removed") return s.enrollment_status === "removed";
    if (studentFilter === "inactive") return !s.is_active;
    return s.class_level === studentFilter;
  });

  const headerContent = (
    <header className="bg-primary text-primary-foreground">
      <div className="container mx-auto px-4 py-4 flex items-center gap-3">
        <Button variant="ghost" size="icon" onClick={() => navigate("/dashboard")} className="text-primary-foreground hover:text-accent">
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <h1 className="text-xl font-heading font-bold">Admin Panel</h1>
      </div>
    </header>
  );

  return (
    <Layout header={headerContent}>
      <main className="container mx-auto px-4 py-8">
        <Tabs defaultValue="students" className="space-y-6">
          <TabsList className="flex-wrap">
            <TabsTrigger value="students"><Users className="w-4 h-4 mr-1" /> Students</TabsTrigger>
            <TabsTrigger value="enrollment"><KeyRound className="w-4 h-4 mr-1" /> Enrollment Codes</TabsTrigger>
            <TabsTrigger value="lessons"><BookOpen className="w-4 h-4 mr-1" /> Lessons</TabsTrigger>
            <TabsTrigger value="activity"><Activity className="w-4 h-4 mr-1" /> Login Activity</TabsTrigger>
            <TabsTrigger value="admins"><Shield className="w-4 h-4 mr-1" /> Admins</TabsTrigger>
          </TabsList>

          {/* ===== STUDENTS TAB ===== */}
          <TabsContent value="students" className="space-y-4">
            <div className="flex flex-wrap gap-2 items-center">
              <Label className="text-sm font-semibold">Filter:</Label>
              <Select value={studentFilter} onValueChange={setStudentFilter}>
                <SelectTrigger className="w-[160px]"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Students</SelectItem>
                  <SelectItem value="pending">⏳ Pending</SelectItem>
                  <SelectItem value="enrolled">✅ Enrolled</SelectItem>
                  <SelectItem value="removed">🚫 Removed</SelectItem>
                  <SelectItem value="inactive">🔒 Deactivated</SelectItem>
                  {classLevels.map((c) => (
                    <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Badge variant="outline" className="ml-auto">{filteredStudents.length} students</Badge>
            </div>

            <Card>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Class</TableHead>
                        <TableHead>Active</TableHead>
                        <TableHead>Joined</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredStudents.map((s) => (
                        <TableRow key={s.id} className={!s.is_active ? "opacity-50" : ""}>
                          <TableCell className="font-medium">{s.display_name || "—"}</TableCell>
                          <TableCell>
                            <Badge variant={s.enrollment_status === "enrolled" ? "default" : s.enrollment_status === "pending" ? "secondary" : "destructive"}>
                              {s.enrollment_status}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Select
                              value={s.class_level}
                              onValueChange={(val) => {
                                if (s.enrollment_status === "enrolled") moveStudent(s.user_id, val);
                                else enrollStudent(s.user_id, val);
                              }}
                            >
                              <SelectTrigger className="w-[120px] h-8 text-xs">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                {classLevels.map((c) => (
                                  <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </TableCell>
                          <TableCell>
                            {s.is_active ? (
                              <Badge className="bg-emerald-500/20 text-emerald-700 border-emerald-300">Active</Badge>
                            ) : (
                              <Badge variant="destructive">Deactivated</Badge>
                            )}
                          </TableCell>
                          <TableCell className="text-xs text-muted-foreground">
                            {new Date(s.created_at).toLocaleDateString()}
                          </TableCell>
                          <TableCell>
                            <div className="flex gap-1 justify-end flex-wrap">
                              {s.enrollment_status !== "enrolled" && (
                                <Button size="sm" variant="outline" className="text-xs h-7" onClick={() => enrollStudent(s.user_id, s.class_level)}>
                                  <UserCheck className="w-3 h-3 mr-1" /> Enroll
                                </Button>
                              )}
                              {s.enrollment_status === "enrolled" && (
                                <Button size="sm" variant="outline" className="text-xs h-7" onClick={() => removeFromClass(s.user_id)}>
                                  <UserX className="w-3 h-3 mr-1" /> Remove
                                </Button>
                              )}
                              <Button size="sm" variant="outline" className="text-xs h-7" onClick={() => toggleDeactivate(s.user_id, s.is_active)}>
                                {s.is_active ? "Deactivate" : "Reactivate"}
                              </Button>
                              <Button size="sm" variant="outline" className="text-xs h-7" onClick={() => { setResetPasswordUserId(s.user_id); setNewPassword(""); }}>
                                <KeyRound className="w-3 h-3" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                      {filteredStudents.length === 0 && (
                        <TableRow>
                          <TableCell colSpan={6} className="text-center text-muted-foreground py-8">No students found</TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>

            {/* Reset Password Dialog */}
            <Dialog open={!!resetPasswordUserId} onOpenChange={(open) => !open && setResetPasswordUserId(null)}>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle className="font-heading">Reset Student Password</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>New Password</Label>
                    <Input type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} placeholder="Min 6 characters" minLength={6} />
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setResetPasswordUserId(null)}>Cancel</Button>
                  <Button onClick={resetPassword} className="bg-accent text-accent-foreground hover:bg-accent/90">Reset Password</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </TabsContent>

          {/* ===== ENROLLMENT CODES TAB ===== */}
          <TabsContent value="enrollment" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="font-heading">Create Enrollment Code</CardTitle>
                <CardDescription>Generate a code students can use to self-enroll into a class</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-3 items-end">
                  <div className="space-y-2">
                    <Label>Class</Label>
                    <Select value={codeClassLevel} onValueChange={setCodeClassLevel}>
                      <SelectTrigger className="w-[140px]"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {classLevels.map((c) => (
                          <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Max Uses (optional)</Label>
                    <Input type="number" value={codeMaxUses} onChange={(e) => setCodeMaxUses(e.target.value)} placeholder="Unlimited" className="w-[120px]" />
                  </div>
                  <Button onClick={createEnrollmentCode} className="bg-accent text-accent-foreground hover:bg-accent/90">
                    <Plus className="w-4 h-4 mr-1" /> Generate Code
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader><CardTitle className="font-heading">Active Codes</CardTitle></CardHeader>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Code</TableHead>
                      <TableHead>Class</TableHead>
                      <TableHead>Uses</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {enrollmentCodes.map((c) => (
                      <TableRow key={c.id}>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <code className="font-mono font-bold tracking-widest text-sm bg-muted px-2 py-1 rounded">{c.code}</code>
                            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => { navigator.clipboard.writeText(c.code); toast.success("Copied!"); }}>
                              <Copy className="w-3 h-3" />
                            </Button>
                          </div>
                        </TableCell>
                        <TableCell>{classLabels[c.class_level] || c.class_level}</TableCell>
                        <TableCell>{c.times_used}{c.max_uses ? ` / ${c.max_uses}` : ""}</TableCell>
                        <TableCell>
                          <Badge variant={c.is_active ? "default" : "secondary"}>
                            {c.is_active ? "Active" : "Inactive"}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Button variant="ghost" size="icon" onClick={() => deleteCode(c.id)}>
                            <Trash2 className="w-4 h-4 text-destructive" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                    {enrollmentCodes.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center text-muted-foreground py-8">No enrollment codes yet</TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ===== LESSONS TAB ===== */}
          <TabsContent value="lessons" className="space-y-6">
            <Card>
              <CardHeader><CardTitle className="font-heading">Add New Lesson</CardTitle></CardHeader>
              <CardContent>
                <form onSubmit={addLesson} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Title</Label>
                    <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Introduction to Plants" required />
                  </div>
                  <div className="space-y-2">
                    <Label>Subject</Label>
                    <Select value={subject} onValueChange={setSubject}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="science">Science</SelectItem>
                        <SelectItem value="math">Mathematics</SelectItem>
                        <SelectItem value="english">English</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Class Level</Label>
                    <Select value={classLevel} onValueChange={setClassLevel}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {classLevels.map((c) => (
                          <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Embed URL</Label>
                    <Input value={embedUrl} onChange={(e) => setEmbedUrl(e.target.value)} placeholder="https://view.genially.com/..." required />
                  </div>
                  <div className="space-y-2 md:col-span-2">
                    <Label>Notes (optional)</Label>
                    <Input value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Key points for students..." />
                  </div>
                  <Button type="submit" disabled={adding} className="bg-accent text-accent-foreground hover:bg-accent/90">
                    <Plus className="w-4 h-4 mr-1" /> {adding ? "Adding..." : "Add Lesson"}
                  </Button>
                </form>
              </CardContent>
            </Card>

            <Card>
              <CardHeader><CardTitle className="font-heading">All Lessons ({lessons.length})</CardTitle></CardHeader>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Title</TableHead>
                      <TableHead>Subject</TableHead>
                      <TableHead>Class</TableHead>
                      <TableHead></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {lessons.map((l) => (
                      <TableRow key={l.id}>
                        <TableCell className="font-medium">{l.title}</TableCell>
                        <TableCell className="capitalize">{l.subject}</TableCell>
                        <TableCell>{l.class_level?.replace("_", " ")}</TableCell>
                        <TableCell>
                          <Button variant="ghost" size="icon" onClick={() => deleteLesson(l.id)}>
                            <Trash2 className="w-4 h-4 text-destructive" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ===== LOGIN ACTIVITY TAB ===== */}
          <TabsContent value="activity">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="font-heading">Login Activity</CardTitle>
                  <Button variant="outline" size="sm" onClick={fetchData}>
                    <RefreshCw className="w-4 h-4 mr-1" /> Refresh
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Student</TableHead>
                      <TableHead>Time</TableHead>
                      <TableHead>Browser</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {loginActivity.map((a) => {
                      const student = students.find((s) => s.user_id === a.user_id);
                      return (
                        <TableRow key={a.id}>
                          <TableCell className="font-medium">{student?.display_name || a.user_id.slice(0, 8)}</TableCell>
                          <TableCell className="text-sm text-muted-foreground">
                            {new Date(a.logged_in_at).toLocaleString()}
                          </TableCell>
                          <TableCell className="text-xs text-muted-foreground max-w-[200px] truncate">
                            {a.user_agent?.slice(0, 60) || "—"}
                          </TableCell>
                        </TableRow>
                      );
                    })}
                    {loginActivity.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={3} className="text-center text-muted-foreground py-8">No login activity yet</TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ===== ADMINS TAB ===== */}
          <TabsContent value="admins" className="space-y-6">
            <Card>
              <CardHeader><CardTitle className="font-heading">Make User Admin</CardTitle></CardHeader>
              <CardContent>
                <div className="flex gap-3">
                  <Select value={adminEmail} onValueChange={setAdminEmail}>
                    <SelectTrigger className="flex-1"><SelectValue placeholder="Select a student..." /></SelectTrigger>
                    <SelectContent>
                      {students.filter((s) => !admins.some((a) => a.user_id === s.user_id)).map((s) => (
                        <SelectItem key={s.user_id} value={s.user_id}>{s.display_name || s.user_id}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Button className="bg-accent text-accent-foreground hover:bg-accent/90" onClick={async () => {
                    if (!adminEmail) return;
                    const { error } = await supabase.from("user_roles").insert({ user_id: adminEmail, role: "admin" as any });
                    if (error) toast.error(error.message);
                    else { toast.success("Admin role granted!"); setAdminEmail(""); fetchData(); }
                  }}>
                    <Shield className="w-4 h-4 mr-1" /> Grant Admin
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader><CardTitle className="font-heading">Current Admins</CardTitle></CardHeader>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {admins.map((a) => {
                      const profile = students.find((s) => s.user_id === a.user_id);
                      return (
                        <TableRow key={a.id}>
                          <TableCell className="font-medium">{profile?.display_name || a.user_id}</TableCell>
                          <TableCell>
                            <Button variant="ghost" size="icon" onClick={async () => {
                              const { error } = await supabase.from("user_roles").delete().eq("id", a.id);
                              if (error) toast.error(error.message);
                              else { toast.success("Admin role removed"); fetchData(); }
                            }}>
                              <Trash2 className="w-4 h-4 text-destructive" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </Layout>
  );
}
