import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const authHeader = req.headers.get("Authorization")!;

    // Verify the caller is admin
    const userClient = createClient(supabaseUrl, Deno.env.get("SUPABASE_PUBLISHABLE_KEY")!, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: { user } } = await userClient.auth.getUser();
    if (!user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const adminClient = createClient(supabaseUrl, serviceRoleKey);

    // Check admin role
    const { data: roles } = await adminClient
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id)
      .eq("role", "admin");

    if (!roles || roles.length === 0) {
      return new Response(JSON.stringify({ error: "Forbidden" }), {
        status: 403,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { action, ...params } = await req.json();

    let result: any;

    switch (action) {
      case "deactivate_student": {
        const { user_id, deactivate } = params;
        // Update profile
        await adminClient.from("profiles").update({ is_active: !deactivate }).eq("user_id", user_id);
        // If deactivating, also ban the user in auth
        if (deactivate) {
          await adminClient.auth.admin.updateUserById(user_id, { ban_duration: "876000h" }); // ~100 years
        } else {
          await adminClient.auth.admin.updateUserById(user_id, { ban_duration: "none" });
        }
        result = { success: true };
        break;
      }

      case "update_class": {
        const { user_id, class_level, enrollment_status } = params;
        const update: any = { class_level, updated_at: new Date().toISOString() };
        if (enrollment_status) update.enrollment_status = enrollment_status;
        await adminClient.from("profiles").update(update).eq("user_id", user_id);
        result = { success: true };
        break;
      }

      case "remove_from_class": {
        const { user_id } = params;
        await adminClient.from("profiles").update({ 
          enrollment_status: "removed",
          updated_at: new Date().toISOString()
        }).eq("user_id", user_id);
        result = { success: true };
        break;
      }

      case "reset_password": {
        const { user_id, new_password } = params;
        const { error } = await adminClient.auth.admin.updateUserById(user_id, {
          password: new_password,
        });
        if (error) throw error;
        result = { success: true };
        break;
      }

      case "force_logout": {
        const { user_id } = params;
        await adminClient.auth.admin.signOut(user_id, "global");
        await adminClient.from("active_sessions").delete().eq("user_id", user_id);
        result = { success: true };
        break;
      }

      default:
        return new Response(JSON.stringify({ error: "Unknown action" }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
    }

    return new Response(JSON.stringify(result), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
